



function addRow(params) {
  let name = document.querySelector('#name')
  let lname = document.querySelector('#lname')
  let age = document.querySelector('#age')
  let table = document.querySelector('table')
  let row = table.insertRow(1)
  row.innerHTML = `<td>${name.value}</td><td>${lname.value}</td><td>${age.value}</td>  <td> <button onclick="save(this)" >save</button><button onclick="edit(this)">edit</button><button onclick="del(this)">del</button></td>`

}

function del(btn) {
  btn.parentElement.parentElement.remove()     
}


function edit(btn)
{
 let tds= btn.parentElement.parentElement.querySelectorAll(`td`)
 tds.forEach(element => {
   element.contentEditable=true;
 });
}


function save(btn)
{
  let tds= btn.parentElement.parentElement.querySelectorAll(`td`)
  tds.forEach(element => {
    element.contentEditable=false;
  });
}